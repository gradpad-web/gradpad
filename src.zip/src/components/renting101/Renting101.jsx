import PropTypes from 'prop-types';

const Renting101 = () => {

  const cardsData = [
    {
      title: "Title",
      description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit.",
      image: "https://images.unsplash.com/photo-1560185893-a55cbc8c57e8?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
    {
      title: "Title",
      description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit.",
      image: "https://images.unsplash.com/photo-1529408686214-b48b8532f72c?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      isReverse: true,
      hasShadow: true
    },
    {
      title: "Title",
      description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit.",
      image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      hasShadow: true
    },
    {
      title: "Title",
      description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit.",
      image: "https://plus.unsplash.com/premium_photo-1663089331117-b4176fef4c9a?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      isReverse: true,
      hasShadow: true
    },
    {
      title: "Title",
      description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum distinctio, atque soluta assumenda eum est laborum corporis? Autem unde ut, harum vel eveniet aliquid provident quas recusandae dolor expedita odit.",
      image: "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      hasShadow: true
    },
  ]

  return (
    <div className="md:mt-5">
      {
        cardsData.map((item, index) => (
          <div key={index} className={`flex flex-col ${item.isReverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center pt-10 pb-12 ${item.hasShadow ? 'separator' : ''} `}>
            <div className="w-full md:w-1/3">
              <div className='flex items-center justify-center flex-col'>
                <div className={`bg-indigo-50 dark:bg-slate-900 md:max-w-[500px] ${item.isReverse ? 'md:-ms-[200px]' : 'md:-me-[200px]'} px-3 sm:px-10 py-10 z-[1]`}>
                  <h2 className='dark:text-white font-semibold uppercase text-2xl mb-5'>{item.title}</h2>
                  <p className='text-base sm:text-lg text-indigo-950 dark:text-neutral-300'>{item.description}</p>
                </div>
              </div>
            </div>
            <div className="w-full md:w-2/3">
              <img src={item.image} alt="image 1" />
            </div>
          </div>
        ))
      }
    </div>
  )
}

Renting101.propTypes = {
  isReverse: PropTypes.any,
  hasShadow: PropTypes.any,
};

export default Renting101;