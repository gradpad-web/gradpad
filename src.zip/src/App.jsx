import { Route, Routes } from "react-router-dom";
import Navbar from "./sections/navbar/Navbar";
import Home from "./Home";
import Footer from "./sections/footer/Footer";
import Service1 from "./components/services/service1";
import Renting101 from "./components/renting101/Renting101";
import Service2 from "./components/services/service2";
import Service3 from "./components/services/service3";
import Service4 from "./components/services/service4";

const App = () => {
  return (
    <div className="bg-white dark:bg-slate-800">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/service1" element={<Service1 />} />
        <Route path="/service2" element={<Service2 />} />
        <Route path="/service3" element={<Service3 />} />
        <Route path="/service4" element={<Service4 />} />
        <Route path="/renting-101" element={<Renting101 />} />
      </Routes>
      <Footer />
    </div>
  );
};

export default App;
