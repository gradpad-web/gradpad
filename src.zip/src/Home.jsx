import Cards from './sections/cards/Cards'
import Testimonials from './sections/testimonials/Testimonials'
import ThreeDCards from './sections/threeDCards/ThreeDCards'
import Hero from './sections/hero/Hero'
import Faq from './sections/faq/Faq'
import Gallery from './sections/gallery/Gallery'
import DataInsight from './sections/dataInsight'
import Team from './sections/team'
import FutureTogether from './sections/futureTogether'

function Home() {
  return (
    <>
      <Hero />
      <Cards />
      <DataInsight />
      <Team />
      <FutureTogether />
      {/* <ThreeDCards /> */}
      <Gallery />
      <Testimonials />
      <Faq />
    </>
  )
}

export default Home