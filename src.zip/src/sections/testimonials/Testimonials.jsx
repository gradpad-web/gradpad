<div className="mb-8 px-4">
        <h3 className="text-slate-50 text-4xl font-semibold text-center">
          Testimonials
        </h3>
        <p className="text-center text-slate-300 text-lg mt-8 max-w-xl mx-auto">
          Get inspired by the feedback of some students, who experienced perfect service and made
          their lives memorable.
        </p>
      </div>


import { motion } from "framer-motion";



const testimonials = {
  top: [
    {
      id: 1,
      img: "https://images.unsplash.com/photo-1627161683077-e34782c24d81?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=703&q=80",
      name: "Sarah W.",
      title: "Just Graduated from BU",
      info: "I was overwhelmed by the apartment hunting process, but this site made everything so simple. I landed my dream apartment in Back Bay just weeks after graduation. Highly recommend!",
    },
    {
      id: 2,
      img: "https://images.unsplash.com/photo-1595211877493-41a4e5f236b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=715&q=80",
      name: "Jake T.",
      title: "Recent Northeastern Grad",
      info: "I thought finding a place in Boston would be a nightmare, especially with my credit history. Thanks to this site, I found a great place and was able to navigate the process like a pro.",
    },
    {
      id: 3,
      img: "https://images.unsplash.com/photo-1614644147798-f8c0fc9da7f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=928&q=80",
      name: "Emma L.",
      title: "First Job in Boston",
      info: "Moving to a new city was daunting, but the resources here gave me all the confidence I needed. I knew exactly what documents to prepare and was able to secure an amazing apartment in Fenway!",
    },
  ],
  middle: [
    {
      id: 1,
      img: "https://images.unsplash.com/photo-1620932934088-fbdb2920e484?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=930&q=80",
      name: "David M.",
      title: "MIT Graduate",
      info: "The market in Boston is so competitive, but this website helped me stand out. I followed the advice step by step and got an offer on my first choice apartment in Cambridge.",
    },
    {
      id: 2,
      img: "https://images.unsplash.com/photo-1589729132389-8f0e0b55b91e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80",
      name: "Rachael P.",
      title: "Transitioning from College Dorms",
      info: "I was clueless about renting off-campus after graduation, but this site was a lifesaver. It made the process straightforward and stress-free.",
    },
    {
      id: 3,
      img: "https://images.unsplash.com/photo-1580518324671-c2f0833a3af3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      name: "Brian K.",
      title: "Young Professional",
      info: "This site took the stress out of apartment hunting. I knew exactly what to expect and what landlords were looking for. I’m now happily settled in a great spot in South Boston!",
    },
    {
      id: 4,
      img: "https://plus.unsplash.com/premium_photo-1670588776139-da93b47afc6f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      name: "Megan S.",
      title: "Moving from Out of State",
      info: "As someone new to Boston, I had no idea where to start. This website guided me through every step and made finding an apartment so much easier than I expected.",
    },
  ],
  bottom: [
    {
      id: 1,
      img: "https://images.unsplash.com/photo-1558222218-b7b54eede3f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      name: "Alex J.",
      title: "Recent Grad with a Co-Signer",
      info: "I was worried about needing a co-signer, but the advice here helped me get everything in order. I found a fantastic apartment near my new job, and the process was smooth.",
    },
    {
      id: 2,
      img: "https://images.unsplash.com/photo-1573497161161-c3e73707e25c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      name: "Jessica F.",
      title: "First-Time Renter",
      info: "I’d never rented before and had no idea how competitive Boston’s market was. The tips and checklists on this site gave me the edge I needed to secure my first apartment.",
    },
    {
      id: 3,
      img: "https://images.unsplash.com/photo-1514222709107-a180c68d72b4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=898&q=80",
      name: "Michael H.",
      title: "Working in Tech",
      info: "The Boston rental market can be brutal, but this website helped me navigate it with ease. I felt prepared and confident, and I ended up with a great place in Seaport!",
    },
  ],
};

const Testimonials = () => {
  return (
    <div className="bg-slate-950 py-12">
      <div className="mb-8 px-4">
        <h3 className="text-slate-50 text-4xl font-semibold text-center">
          Testimonials
        </h3>
        <p className="text-center text-slate-300 text-lg mt-8 max-w-xl mx-auto">
          Get inspired by the feedback of some students, who experienced perfect service and made
          their lives memorable.
        </p>
      </div>
      <div className="p-4 overflow-x-hidden relative">
        <div className="absolute top-0 bottom-0 left-0 w-24 z-[1] bg-gradient-to-r from-slate-900 to-transparent" />

        <div className="flex items-center mb-4">
          <TestimonialList list={testimonials.top} duration={125} />
          <TestimonialList list={testimonials.top} duration={125} />
          <TestimonialList list={testimonials.top} duration={125} />
        </div>
        <div className="flex items-center mb-4">
          <TestimonialList list={testimonials.middle} duration={75} reverse />
          <TestimonialList list={testimonials.middle} duration={75} reverse />
          <TestimonialList list={testimonials.middle} duration={75} reverse />
        </div>
        <div className="flex items-center">
          <TestimonialList list={testimonials.bottom} duration={275} />
          <TestimonialList list={testimonials.bottom} duration={275} />
          <TestimonialList list={testimonials.bottom} duration={275} />
        </div>

        <div className="absolute top-0 bottom-0 right-0 w-24 z-[1] bg-gradient-to-l from-slate-900 to-transparent" />
      </div>
    </div>
  );
};

const TestimonialList = ({ list, reverse = false, duration = 50 }) => {
  return (
    <motion.div
      initial={{ translateX: reverse ? "-100%" : "0%" }}
      animate={{ translateX: reverse ? "0%" : "-100%" }}
      transition={{ duration, repeat: Infinity, ease: "linear" }}
      className="flex gap-4 px-2"
    >
      {list.map((t) => {
        return (
          <div
            key={t.id}
            className="shrink-0 w-[500px] grid grid-cols-[7rem,_1fr] rounded-lg overflow-hidden relative"
          >
            <img src={t.img} className="w-full h-44 object-cover" />
            <div className="bg-slate-900 text-slate-50 p-4">
              <span className="block font-semibold text-lg mb-1">{t.name}</span>
              <span className="block mb-3 text-sm font-medium">{t.title}</span>
              <span className="block text-sm text-slate-300">{t.info}</span>
            </div>
            {/* <span className="text-7xl absolute top-2 right-2 text-slate-700">
              "
            </span> */}
          </div>
        );
      })}
    </motion.div>
  );
};

export default Testimonials;