import img1 from "../../assets/img1.jpg";
import img2 from "../../assets/img2.jpg";
import img3 from "../../assets/img3.jpg";
import img4 from "../../assets/img4.jpg";

const Cards = () => {
  const cardsData = [
    {
      title: 'Boston',
      description: `Dive and experience the city's modern vibe and historical charm. The city is known for 
      education and innovation. Make this place a home away from home, we have got you covered.`,
      imgPath: img1,
    },
    {
      title: 'NYC',
      description: `A city that never sleeps, offers a wide range of opportunities to students. Make your ideal 
      place to thrive and a prime location for professional real estate agents`,
      imgPath: img2,
    },
    {
      title: 'New England',
      description: ` Discover the diverse possibilities for students and real estate agents to connect for the 
      perfect rental.`,
      imgPath: img3,
    },
    {
      title: 'Nebraska',
      description: `Experience the charm of the Midwest in Nebraska, where excellent education is coupled with affordable living. Enjoy a comfortable life by residing in a contemporary rental apartment near campus and nature.`,
      imgPath: img4,
    },
  ]

  return (
    <div className="container mx-auto px-3 pb-10 md:pb-20">
      <div className="max-w-3xl text-center mx-auto mb-10">
        <h2 className="text-2xl md:text-4xl font-semibold capitalize mb-5 dark:text-white">Explore Cities</h2>
        <p className="dark:text-neutral-300 text-xl">Find a convenient rental accommodation in the lively city of your choice.</p>
      </div>
      <div className="card-container flex max-w-[1200px] w-full h-[200px] md:h-[400px] mx-auto gap-[10px] lg:gap-[40px]">
        {
          cardsData.map((item, index) => (
            <div key={index} className="card min-w-[30px] md:min-w-[100px] h-full overflow-hidden flex items-end flex-grow cursor-pointer relative rounded-[20px] md:rounded-[30px]">
              <img className="w-full h-full block background" src={item.imgPath} alt="" />
              <div className="flex flex-col items-start absolute left-[10px] right-[10px] bottom-[20px] overflow-hidden z-[1] card-content">
                <h3 className="title fw-bold text-2xl mb-3">{item.title}</h3>
                <p className="title line-clamp-2">{item.description}</p>
              </div>
              <div className="backdrop"></div>
            </div>
          ))
        }
      </div>
    </div>
  )
}

export default Cards