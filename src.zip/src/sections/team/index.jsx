import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import brandenImg from "../../assets/branden.jpeg";
import ianImg from "../../assets/ian.jpeg";

const Team = () => {
  const targetRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
  });

  return (
    <>
      <div className="container mx-auto px-3 pt-10 md:pt-20">
        <div className="max-w-3xl text-center mx-auto mb-10">
            <h2 className="text-2xl md:text-4xl font-semibold capitalize mb-5 dark:text-white">Meet our team</h2>
            <p className="dark:text-neutral-300 text-xl">United by vision; Our Team at a time.</p>
        </div>
      </div>
      <section ref={targetRef} className="flex bg-black text-white">
        <Content content={items} />
        <Images content={items} scrollYProgress={scrollYProgress} />
      </section>
    </>
  );
};

const Content = ({ content }) => {
  return (
    <div className="w-full">
      {content.map(({ id, title, description }, idx) => (
        <div
          key={id}
          className={`p-3 sm:p-8 h-screen flex flex-col justify-center ${
            idx % 2 ? "bg-white dark:bg-slate-800 text-black dark:text-white" : "bg-teal text-white"
          }`}
        >
          <h3 className="text-3xl font-medium mb-10">{title}</h3>
          <p className="font-light w-full max-w-md">{description}</p>
        </div>
      ))}
    </div>
  );
};

const Images = ({ content, scrollYProgress }) => {
  const top = useTransform(
    scrollYProgress,
    [0, 1],
    [`-${(content.length - 1) * 100}vh`, "0vh"]
  );

  return (
    <div className="h-screen overflow-hidden sticky top-0 w-full">
      <motion.div style={{ top }} className="absolute left-0 right-0">
        {[...content].reverse().map(({ img, id, title }) => (
          <img
            key={id}
            alt={title}
            className="h-screen w-full object-cover"
            src={img}
          />
        ))}
      </motion.div>
    </div>
  );
};

export default Team;

const items = [
  {
    id: 1,
    title: "Meet our incredible team",
    description: "",
    img: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?q=80&w=1498&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
  {
    id: 2,
    title: "CEO / Founder",
    description:
      " UNH senior and Boston real estate agent, who has been a real estate agent for multiple years.",
    img: brandenImg,
  },
  {
    id: 3,
    title: "Ian Hale",
    description:
      "With over 12 years of expertise, he serves as a Fractional CTO for multiple startups. A graduate of the University of British Columbia, he brings a wealth of experience and knowledge to each venture.",
    img: ianImg,
  },
  // {
  //   id: 4,
  //   title: "Adam Okane",
  //   description:
  //     "Co-owner of O'Kane Marketing, launched the successful Swipewipe app through Afternoon Products.",
  //   img: "https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=2970&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  // },
  // {
  //   id: 5,
  //   title: "Mike Veilleux",
  //   description:
  //     "York IE's co-founder and CTO, and Josh Cyr, Director of UNH's E Center.",
  //   img: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2970&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  // },
];