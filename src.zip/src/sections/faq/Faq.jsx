import React, { useEffect } from "react";
import { Accordion, AccordionItem as Item } from '@szhsin/react-accordion';
import { IoIosArrowDown } from "react-icons/io";
import PropTypes from 'prop-types';
import parse from 'html-react-parser';
import {
  animate,
  useMotionTemplate,
  useMotionValue,
  motion,
} from "framer-motion";

const AccordionItem = ({ header, ...rest }) => {
  const turn = useMotionValue(0);

  useEffect(() => {
    animate(turn, 1, {
      ease: "linear",
      duration: 5,
      repeat: Infinity,
    });
  }, []);

  const backgroundImage = useMotionTemplate`conic-gradient(from ${turn}turn, #a78bfa00 75%, #008080 100%)`;
  return (
    <>
    <div
      className="relative w-full mb-3 rounded-[6px] border border-teal show-border-outter"
    >
      <Item
        {...rest}
        header={({ state: { isEnter } }) => (
          <>
            {header}
            <IoIosArrowDown className={`ml-auto transition-transform duration-200 ease-out ${isEnter && "rotate-180"}`} style={{flex: "0 0 16px"}} />
          </>
        )}
        className="relative z-[2]"
        buttonProps={{
          className: ({ isEnter }) =>
            `flex w-full text-teal font-semibold p-4 text-left rounded-[6px] gap-2 ${isEnter && "!text-white !bg-teal !rounded-t-md !rounded-b-none "
            }`
        }}
        contentProps={{
          className: "transition-height duration-200 ease-out"
        }}
        panelProps={{ className: "p-4 dark:text-white" }}
      />

      <div className="pointer-events-none absolute inset-0 z-[1] rounded-[6px]">
        <motion.div
          style={{
            backgroundImage,
          }}
          className="mask-with-browser-support absolute inset-[0px] rounded-[6px] show-border border-transparent bg-origin-border"
        />
      </div>
    </div>
    </>
  )
};

const Faq = () => {

  const faqList = [
//     {
//       question: `What services does After-Grad pad offer?`,
//       answer: `We offer comprehensive resources for students seeking post-graduation housing, including 
// city guides, rental listings, financial aid, and referral programs.`,
//     },
//     {
//       question: `How to create the account for free?`,
//       answer: `To create an account, click on the 'Sign Up' button on the top right corner of our homepage 
// and follow the instructions.`,
//     },
//     {
//       question: `Why do I choose the After-Grad pad?`,
//       answer: `Unlike other rental websites, we focus specifically on the needs of graduating students, 
// providing tailored resources, guidance, and a streamlined process to help you find your perfect home.`,
//     },
//     {
//       question: `How can I share my experience and provide the feedback?`,
//       answer: `We value your feedback! You can email us at [Email Address] or fill out our feedback form 
// [Link to Feedback Form].`,
//     },
//     {
//       question: `What payment system do you offer?`,
//       answer: `As soon as you connect with the realtor and are satisfied with one-to-one consultation, you 
// can initiate your payment process. We provided various secured payment systems.`,
//     },
//     {
//       question: `How do I personalize my rental search?`,
//       answer: `You can click on the advanced search filter in the find right place and personalise your needs.`,
//     },
//     {
//       question: `What amenities do you offer for the students?`,
//       answer: `We understand your concerns, we offer a wide range of amenities that are comfortable and 
// convenient for living. See our service section and find the list of amenities.`,
//     },
    {
      question: `Would you like to provide the list of documents needed to apply for a rental area?`,
      answer: parse(`
        <p classname="mb-2">Yes, the required documents typically include:</p>
        <ul classname="list-disc ps-8">
          <li>Proof of income (pay stubs, offer letter, or bank statements)</li>
          <li>Employment verification letter</li>
          <li>Credit report</li>
          <li>References (previous landlords or personal references)</li>
          <li>Photo ID (driver&#39;s license or passport)</li>
          <li>Rental application form</li>
          <li>Cosigner or guarantor information (if applicable)</li>
        </ul>
      `),
    },
    {
      question: `What is the follow-up time to connect the student to an agent?`,
      answer: `The follow-up time is usually within 24 to 48 hours after receiving the initial
        inquiry. Our team ensures prompt responses to match students with
        suitable agents quickly.`,
    },
    {
      question: `What are the specific ethical and privacy policy considerations?`,
      answer: parse(`
        <p classname="mb-2">We prioritize the privacy and confidentiality of our clients. Our ethical and
        privacy policies include:</p>
        <ul classname="list-disc ps-8">
          <li>Protecting personal and financial information</li>
          <li>Ensuring transparent communication</li>
          <li>Avoiding conflicts of interest</li>
          <li>Adhering to fair housing laws</li>
          <li>Maintaining client confidentiality at all times</li>
        </ul>
      `),
    },
    {
      question: `What are the specific terms and conditions?`,
      answer: parse(`
        <p classname="mb-2">Our terms and conditions include:</p>
        <ul classname="list-disc ps-8">
          <li>A clear explanation of our services and fees</li>
          <li>Details on the rental process and agent responsibilities</li>
          <li>Cancellation policies</li>
          <li>Dispute resolution procedures</li>
          <li>Tenant responsibilities and rights</li>
          <li>Data usage and protection policies</li>
        </ul>
      `),
    },
    {
      question: `Would you kindly provide the briefing on the full deposit payment system
      or are there any installment plans?`,
      answer: `The full deposit payment system typically requires a security deposit equal
      to one month's rent, paid upfront. However, we do offer installment plans
      in certain situations to accommodate student's financial needs. Details of
      the installment plans can be discussed with the assigned agent.`,
    },
  ];

  return (
    <div className="container mx-auto px-3 py-10">
      <div className="max-w-3xl text-center mx-auto mb-5">
        <h2 className="text-2xl md:text-4xl font-semibold mb-5 dark:text-white">FAQs</h2>
        <p className="dark:text-neutral-300">Ask away to find your perfect place! We have got answers.</p>
      </div>
      <div className="my-4 max-w-4xl mx-auto">
        <Accordion transition transitionTimeout={200}>
          {
            faqList.map((item, index) => (
              <AccordionItem 
                key={index} 
                header={item.question} 
                initialEntered={index === 0}
              >
                {item.answer}
              </AccordionItem>
            ))
          }
        </Accordion>
      </div>
    </div>
  );
};

AccordionItem.propTypes = {
  header: PropTypes.any,
};

export default Faq;